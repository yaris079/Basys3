/*
 * Copyright (c) 2009-2012 Xilinx, Inc.  All rights reserved.
 *
 * Xilinx, Inc.
 * XILINX IS PROVIDING THIS DESIGN, CODE, OR INFORMATION "AS IS" AS A
 * COURTESY TO YOU.  BY PROVIDING THIS DESIGN, CODE, OR INFORMATION AS
 * ONE POSSIBLE   IMPLEMENTATION OF THIS FEATURE, APPLICATION OR
 * STANDARD, XILINX IS MAKING NO REPRESENTATION THAT THIS IMPLEMENTATION
 * IS FREE FROM ANY CLAIMS OF INFRINGEMENT, AND YOU ARE RESPONSIBLE
 * FOR OBTAINING ANY RIGHTS YOU MAY REQUIRE FOR YOUR IMPLEMENTATION.
 * XILINX EXPRESSLY DISCLAIMS ANY WARRANTY WHATSOEVER WITH RESPECT TO
 * THE ADEQUACY OF THE IMPLEMENTATION, INCLUDING BUT NOT LIMITED TO
 * ANY WARRANTIES OR REPRESENTATIONS THAT THIS IMPLEMENTATION IS FREE
 * FROM CLAIMS OF INFRINGEMENT, IMPLIED WARRANTIES OF MERCHANTABILITY
 * AND FITNESS FOR A PARTICULAR PURPOSE.
 *
 */

/*
 * helloworld.c: simple test application
 *
 * This application configures UART 16550 to baud rate 9600.
 * PS7 UART (Zynq) is not initialized by this application, since
 * bootrom/bsp configures it to baud rate 115200
 *
 * ------------------------------------------------
 * | UART TYPE   BAUD RATE                        |
 * ------------------------------------------------
 *   uartns550   9600
 *   uartlite    Configurable only in HW design
 *   ps7_uart    115200 (configured by bootrom/bsp)
 */

#include <stdio.h>
#include "xparameters.h"
#include "platform.h"
#include "xgpio.h"

#define LED 0x01
#define LED_DELAY     1000000
#define LED_CHANNEL 1

XGpio Gpio;

void print(char *str);

int main()
{
    init_platform();
    u32 Data;
    int Status;
    int Delay;
    Status = XGpio_Initialize(&Gpio,XPAR_AXI_GPIO_0_DEVICE_ID);
    if(Status != XST_SUCCESS){
    	return XST_FAILURE;
    }
    print("GPIO Test!!\n\r");
    XGpio_SetDataDirection(&Gpio,1,~LED);
    while(1){
/*
		 * Read the state of the data so that only the LED state can be
		 * modified
		 */
		Data = XGpio_DiscreteRead(&Gpio, LED_CHANNEL);

		/*
		 * Set the LED to the opposite state such that it blinks using
		 * the first method, two methods are used for illustration
		 * purposes only
		 */
		if (Data & LED) {
			XGpio_DiscreteWrite(&Gpio, LED_CHANNEL, Data & ~LED);
		} else {
			XGpio_DiscreteWrite(&Gpio, LED_CHANNEL, Data | LED);
		}

		/* Wait a small amount of time so the LED is visible */

		for (Delay = 0; Delay < LED_DELAY; Delay++);

		/*
		 * Read the state of the data so that only the LED state can be
		 * modified
		 */
		Data = XGpio_DiscreteRead(&Gpio, LED_CHANNEL);

		/*
		 * Set the LED to the opposite state such that it blinks using
		 * the other API functions
		 */
		if (Data & LED) {
			XGpio_DiscreteClear(&Gpio, LED_CHANNEL, LED);
		} else {
			XGpio_DiscreteSet(&Gpio, LED_CHANNEL, LED);
		}

		/* Wait a small amount of time so the LED is visible */

		for (Delay = 0; Delay < LED_DELAY; Delay++);
}
    return 0;
}
